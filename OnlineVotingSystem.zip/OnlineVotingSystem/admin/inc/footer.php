

<div class="row bg-black text-center text-white">
    <div class="col-12 my-3">
      <p> &copy; Copyright 2002 - All Rights Resereved  <br/>
            Developed by Girjesh
      </p>
    </div>

</div>
<script src="../assets/js/jquery.min.js"></script>
<script src="../assets/js/bootstrap.min.js"></script>
</body>
</html>